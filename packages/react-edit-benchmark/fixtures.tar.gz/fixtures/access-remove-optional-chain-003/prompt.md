# Fix the bug in `canvas.js`

Optional chaining was removed from a property access.

Find and fix this issue.