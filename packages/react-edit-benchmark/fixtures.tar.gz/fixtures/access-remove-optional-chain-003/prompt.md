# Fix the bug in `astUtils.js`

Optional chaining was removed from a property access.

Find and fix this issue.