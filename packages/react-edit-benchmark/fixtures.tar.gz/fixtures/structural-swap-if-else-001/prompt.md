# Fix the bug in `resolveBoxStyle.js`

The if and else branches are swapped.

The issue starts around line 72.

Swap the if and else branch bodies back to their original positions.