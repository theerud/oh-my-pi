# Fix the bug in `importFile.js`

The if and else branches are swapped (condition should be negated).

The issue starts around line 34.

Swap the if and else branch bodies back to their original positions. The condition should be negated to match.