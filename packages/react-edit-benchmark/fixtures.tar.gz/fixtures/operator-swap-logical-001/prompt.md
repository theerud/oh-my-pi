# Fix the bug in `withPermissionsCheck.js`

A boolean operator is incorrect.

The issue is on line 23.

Use the intended boolean operator.