# Fix the bug in `profiling.js`

A boolean operator is incorrect.

The issue is on line 6.

Use the intended boolean operator.