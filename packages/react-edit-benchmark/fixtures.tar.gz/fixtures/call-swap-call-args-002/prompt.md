# Fix the bug in `FlamegraphChartBuilder.js`

Two arguments in a call are swapped.

The issue is in the `getChartData` function.

Swap the two arguments to their original order.