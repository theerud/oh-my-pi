# Fix the bug in `ReactFlightDOMClientBrowser.js`

Two arguments in a call are swapped.

The issue is near the end of the file.

Swap the two arguments to their original order.