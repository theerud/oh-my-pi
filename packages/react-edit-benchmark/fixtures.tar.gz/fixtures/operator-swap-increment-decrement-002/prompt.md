# Fix the bug in `ReactFlightWebpackNodeRegister.js`

An increment/decrement operator points the wrong direction.

The issue is in the `register` function.

Replace the increment/decrement operator with the intended one.