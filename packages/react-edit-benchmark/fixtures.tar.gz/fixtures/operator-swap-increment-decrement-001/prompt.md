# Fix the bug in `ReactFlightClientConfigTargetTurbopackServer.js`

An increment/decrement operator points the wrong direction.

The issue is on line 24.

Replace the increment/decrement operator with the intended one.