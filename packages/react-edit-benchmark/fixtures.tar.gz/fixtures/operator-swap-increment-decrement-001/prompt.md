# Fix the bug in `ReactFlightDOMClientNode.js`

An increment/decrement operator points the wrong direction.

The issue is on line 115.

Replace the increment/decrement operator with the intended one.