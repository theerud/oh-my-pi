# Fix the bug in `ReactNoopFlightServer.js`

A boolean literal is inverted.

The issue is around the middle of the file.

Flip the boolean literal to the intended value.