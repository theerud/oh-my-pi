# Fix the bug in `colors.js`

A nullish coalescing operator was swapped.

The issue is on line 84.

Use the intended nullish/logical operator.