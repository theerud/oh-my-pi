# Fix the bug in `getBatchRange.js`

A nullish coalescing operator was swapped.

The issue is on line 25.

Use the intended nullish/logical operator.