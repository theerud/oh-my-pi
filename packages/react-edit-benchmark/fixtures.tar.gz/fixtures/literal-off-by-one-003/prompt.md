# Fix the bug in `InspectedElement.js`

A numeric boundary has an off-by-one error.

Find and fix this issue.