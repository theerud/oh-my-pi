# Fix the bug in `NativeEventsView.js`

Two adjacent statements are in the wrong order.

The issue is near the end of the file.

Swap the two adjacent lines back to their original order.