# Fix the bug in `ReactNoopFlightServer.js`

Two adjacent statements are in the wrong order.

The issue is around the middle of the file.

Swap the two adjacent lines back to their original order.