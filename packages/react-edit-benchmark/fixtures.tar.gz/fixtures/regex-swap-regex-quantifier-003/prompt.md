# Fix the bug in `ReactFlightStackConfigV8.js`

A regex quantifier was swapped, changing whitespace matching.

Find and fix this issue.