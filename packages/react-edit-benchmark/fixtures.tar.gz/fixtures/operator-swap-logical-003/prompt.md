# Fix the bug in `ReactFlightDOMClientBrowser.js`

A boolean operator is incorrect.

Find and fix this issue.