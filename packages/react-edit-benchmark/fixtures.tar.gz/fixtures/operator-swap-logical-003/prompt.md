# Fix the bug in `DevToolsFiberComponentStack.js`

A boolean operator is incorrect.

Find and fix this issue.