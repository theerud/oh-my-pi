# Fix the bug in `hooks.js`

An arithmetic operator was swapped.

Find and fix this issue.