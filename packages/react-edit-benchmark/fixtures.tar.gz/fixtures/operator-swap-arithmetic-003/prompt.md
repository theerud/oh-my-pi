# Fix the bug in `ReactFlightDOMServerEdge.js`

An arithmetic operator was swapped.

Find and fix this issue.