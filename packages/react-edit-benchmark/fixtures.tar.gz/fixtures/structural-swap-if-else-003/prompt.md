# Fix the bug in `ReactDOMFizzStaticNode.js`

The if and else branches are swapped (condition should be negated).

The fix may involve multiple lines.