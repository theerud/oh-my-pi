# Fix the bug in `ReactPerformanceTrackProperties.js`

An identifier is misspelled in multiple separate locations.

Find and fix all occurrences of this issue.