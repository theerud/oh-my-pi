# Fix the bug in `ReactFlightDOMClientEdge.js`

A boolean literal is inverted.

Find and fix this issue.