# Fix the bug in `fallbackEvalContext.js`

An arithmetic operator was swapped.

The issue is on line 4.

Correct the arithmetic operator.