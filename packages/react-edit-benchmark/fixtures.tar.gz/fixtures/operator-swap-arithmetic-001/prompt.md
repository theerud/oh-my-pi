# Fix the bug in `id-generator.js`

An arithmetic operator was swapped.

The issue is on line 26.

Correct the arithmetic operator.