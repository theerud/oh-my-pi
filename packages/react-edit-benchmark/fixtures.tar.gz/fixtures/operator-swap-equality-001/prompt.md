# Fix the bug in `backend.js`

An equality operator is inverted.

The issue is on line 22.

Fix the equality comparison operator.