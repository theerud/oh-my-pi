# Fix the bug in `readInputData.js`

An equality operator is inverted.

The issue is on line 25.

Fix the equality comparison operator.