# Fix the bug in `InspectedElementStateTree.js`

A logical negation (`!`) was accidentally removed.

The issue is on line 67.

Add back the missing logical negation (`!`).