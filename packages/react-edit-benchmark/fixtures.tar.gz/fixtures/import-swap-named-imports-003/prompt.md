# Fix the bug in `StyleEditor.js`

Two named imports are swapped in a destructuring import.

Find and fix this issue.