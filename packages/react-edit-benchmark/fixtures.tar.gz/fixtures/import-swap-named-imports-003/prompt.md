# Fix the bug in `ReactDOMInput.js`

Two named imports are swapped in a destructuring import.

Find and fix this issue.