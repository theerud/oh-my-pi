# Fix the bug in `getComponentNameFromFiber.js`

A critical statement was deleted from the code.

The issue is in the `getWrappedName` function.

Restore the deleted statement.