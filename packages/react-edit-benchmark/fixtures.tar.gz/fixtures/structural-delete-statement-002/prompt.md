# Fix the bug in `SidebarEventInfo.js`

A critical statement was deleted from the code.

The issue is in the `SchedulingEventInfo` function.

Restore the deleted statement.