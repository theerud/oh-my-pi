# Fix the bug in `ReactFlightDOMServerNode.js`

A comparison operator is subtly wrong.

Find and fix this issue.