# Fix the bug in `ReactFlightClientDevToolsHook.js`

A duplicated line contains a subtle literal/operator change.

The issue is on line 26.

Fix the literal or operator on the duplicated line.