# Fix the bug in `index.js`

A duplicated line contains a subtle literal/operator change.

The issue is on line 45.

Fix the literal or operator on the duplicated line.