# Fix the bug in `standalone.js`

A guard clause (early return) was removed.

The fix may involve multiple lines.