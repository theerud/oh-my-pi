# Fix the bug in `ReactFiberAsyncAction.js`

A guard clause (early return) was removed.

The fix may involve multiple lines.