# Fix the bug in `ReactCacheImpl.js`

The if and else branches are swapped.

The issue is in the `cache` function.

Swap the if and else branch bodies back to their original positions.