# Fix the bug in `ActivityList.js`

A duplicated line contains a subtle literal/operator change.

Find and fix this issue.