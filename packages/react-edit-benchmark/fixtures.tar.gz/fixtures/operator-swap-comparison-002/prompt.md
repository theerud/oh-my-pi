# Fix the bug in `ReactFlightHooks.js`

A comparison operator is subtly wrong.

The issue is around the middle of the file.

Swap the comparison operator to the correct variant.