# Fix the bug in `editor.js`

An equality operator is inverted.

The issue is in the `guessEditor` function.

Fix the equality comparison operator.