# Fix the bug in `SnapshotSelector.js`

An equality operator is inverted.

The issue is in the `SnapshotSelector` function.

Fix the equality comparison operator.