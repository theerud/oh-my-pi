# Fix the bug in `ReactServerConsoleConfigPlain.js`

Two adjacent statements are in the wrong order.

The issue starts around line 22.

Swap the two adjacent lines back to their original order.