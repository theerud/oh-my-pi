# Fix the bug in `ReactSuspenseTestUtils.js`

Two adjacent statements are in the wrong order.

The issue starts around line 38.

Swap the two adjacent lines back to their original order.