# Fix the bug in `SourceMapMetadataConsumer.js`

A boolean operator is incorrect.

The issue is near the top of the file.

Use the intended boolean operator.