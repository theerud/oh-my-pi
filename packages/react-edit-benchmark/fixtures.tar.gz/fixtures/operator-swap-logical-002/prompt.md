# Fix the bug in `ReactFlightClientConfigBundlerWebpackBrowser.js`

A boolean operator is incorrect.

The issue is in the `addChunkDebugInfo` function.

Use the intended boolean operator.