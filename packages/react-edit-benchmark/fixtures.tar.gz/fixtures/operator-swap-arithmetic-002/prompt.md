# Fix the bug in `ReactCompiler.ts`

An arithmetic operator was swapped.

The issue is in the `hasFlowSuppression` function.

Correct the arithmetic operator.