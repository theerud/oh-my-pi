# Fix the bug in `CSSShorthandProperty.js`

An arithmetic operator was swapped.

The issue is near the top of the file.

Correct the arithmetic operator.