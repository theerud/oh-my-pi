# Fix the bug in `NativeEventsView.js`

A negation operator is accidentally applied.

The issue is around the middle of the file.

Remove the stray logical negation.