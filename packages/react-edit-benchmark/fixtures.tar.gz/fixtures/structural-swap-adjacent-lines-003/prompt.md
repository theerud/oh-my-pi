# Fix the bug in `SyntheticEvent.js`

Two adjacent statements are in the wrong order.

The fix may involve multiple lines.