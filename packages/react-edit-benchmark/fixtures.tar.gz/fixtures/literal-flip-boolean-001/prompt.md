# Fix the bug in `DevToolsFeatureFlags.core-fb.js`

A boolean literal is inverted.

The issue is on line 17.

Flip the boolean literal to the intended value.