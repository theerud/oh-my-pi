# Fix the bug in `testHelpers.js`

A boolean literal is inverted.

The issue is on line 20.

Flip the boolean literal to the intended value.