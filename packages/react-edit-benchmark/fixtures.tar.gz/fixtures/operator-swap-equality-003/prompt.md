# Fix the bug in `ReactFiberTransition.js`

An equality operator is inverted.

Find and fix this issue.