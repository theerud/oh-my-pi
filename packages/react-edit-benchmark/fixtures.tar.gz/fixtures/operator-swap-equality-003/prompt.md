# Fix the bug in `hooks.js`

An equality operator is inverted.

Find and fix this issue.