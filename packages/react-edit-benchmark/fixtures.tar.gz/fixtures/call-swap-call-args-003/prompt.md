# Fix the bug in `ReactDOMEventListener.js`

Two arguments in a call are swapped.

Find and fix this issue.