# Fix the bug in `SyntheticEvent.js`

Two arguments in a call are swapped.

Find and fix this issue.