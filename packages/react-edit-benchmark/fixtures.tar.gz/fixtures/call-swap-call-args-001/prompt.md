# Fix the bug in `testHelpers.js`

Two arguments in a call are swapped.

The issue is on line 14.

Swap the two arguments to their original order.