# Fix the bug in `ReactFlightUnbundledReferences.js`

A negation operator is accidentally applied.

Find and fix this issue.