# Fix the bug in `BeforeInputEventPlugin.js`

A logical negation (`!`) was accidentally removed.

Find and fix this issue.