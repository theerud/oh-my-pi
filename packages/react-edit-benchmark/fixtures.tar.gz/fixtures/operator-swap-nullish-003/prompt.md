# Fix the bug in `hookNamesCache.js`

A nullish coalescing operator was swapped.

Find and fix this issue.