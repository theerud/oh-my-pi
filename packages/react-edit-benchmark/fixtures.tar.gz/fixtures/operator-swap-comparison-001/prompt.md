# Fix the bug in `index.js`

A comparison operator is subtly wrong.

The issue is on line 63.

Swap the comparison operator to the correct variant.