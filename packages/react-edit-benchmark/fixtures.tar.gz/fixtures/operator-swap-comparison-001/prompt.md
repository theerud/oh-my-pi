# Fix the bug in `useSmartTooltip.js`

A comparison operator is subtly wrong.

The issue is on line 57.

Swap the comparison operator to the correct variant.