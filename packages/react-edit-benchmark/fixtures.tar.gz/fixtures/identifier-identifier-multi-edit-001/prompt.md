# Fix the bug in `ReactDOMUpdatePriority.js`

An identifier is misspelled in multiple separate locations.

The issue is on line 41.

Restore the identifier to its original spelling in all affected locations.