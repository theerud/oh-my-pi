# Fix the bug in `UnsupportedVersionDialog.js`

A critical statement was deleted from the code.

The issue starts around line 22.

Restore the deleted statement.