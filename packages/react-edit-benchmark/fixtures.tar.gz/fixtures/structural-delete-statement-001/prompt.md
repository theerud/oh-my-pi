# Fix the bug in `geometry.js`

A critical statement was deleted from the code.

The issue starts around line 127.

Restore the deleted statement.